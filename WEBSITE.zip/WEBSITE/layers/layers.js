var wms_layers = [];


        var lyr_GoogleSatellite_0 = new ol.layer.Tile({
            'title': 'Google Satellite',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: ' ',
                url: 'https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}'
            })
        });
var lyr_LandSurfaceTemperatureAus_1 = new ol.layer.Image({
        opacity: 1,
        
    title: 'LandSurfaceTemperature-Aus<br />' ,
        
        
        source: new ol.source.ImageStatic({
            url: "./layers/LandSurfaceTemperatureAus_1.png",
            attributions: ' ',
            projection: 'EPSG:3857',
            alwaysInRange: true,
            imageExtent: [-20037016.685564, -44927335.427097, 19459379.310360, 44927335.427095]
        })
    });
var lyr_BurnedAreaAus_2 = new ol.layer.Image({
        opacity: 1,
        
    title: 'BurnedArea-Aus<br />' ,
        
        
        source: new ol.source.ImageStatic({
            url: "./layers/BurnedAreaAus_2.png",
            attributions: ' ',
            projection: 'EPSG:3857',
            alwaysInRange: true,
            imageExtent: [12570000.000020, -5426520.025113, 17711999.999972, -1021337.066113]
        })
    });
var lyr_ForestLossAus_3 = new ol.layer.Image({
        opacity: 1,
        
    title: 'ForestLoss-Aus<br />' ,
        
        
        source: new ol.source.ImageStatic({
            url: "./layers/ForestLossAus_3.png",
            attributions: ' ',
            projection: 'EPSG:3857',
            alwaysInRange: true,
            imageExtent: [12570000.000020, -5426520.025113, 17711999.999972, -1021337.066113]
        })
    });

lyr_GoogleSatellite_0.setVisible(true);lyr_LandSurfaceTemperatureAus_1.setVisible(true);lyr_BurnedAreaAus_2.setVisible(true);lyr_ForestLossAus_3.setVisible(true);
var layersList = [lyr_GoogleSatellite_0,lyr_LandSurfaceTemperatureAus_1,lyr_BurnedAreaAus_2,lyr_ForestLossAus_3];
