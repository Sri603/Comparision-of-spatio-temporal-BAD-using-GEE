var wms_layers = [];


        var lyr_GoogleSatellite_0 = new ol.layer.Tile({
            'title': 'Google Satellite',
            'type':'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: ' ',
                url: 'https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}'
            })
        });
var lyr_NDVI_1 = new ol.layer.Image({
                            opacity: 1,
                            title: 'NDVI',
                            
                            
                            source: new ol.source.ImageStatic({
                                url: "./layers/NDVI_1.png",
                                attributions: ' ',
                                projection: 'EPSG:3857',
                                alwaysInRange: true,
                                imageExtent: [12570000.000000, -5426520.025055, 17715000.000000, -1019311.420452]
                            })
                        });
var lyr_LandSurfTemp_Aus_2019_2 = new ol.layer.Image({
                            opacity: 1,
                            title: 'LandSurfTemp_Aus_2019',
                            
                            
                            source: new ol.source.ImageStatic({
                                url: "./layers/LandSurfTemp_Aus_2019_2.png",
                                attributions: ' ',
                                projection: 'EPSG:3857',
                                alwaysInRange: true,
                                imageExtent: [-20037016.685578, -44927335.427097, 19459379.310345, 44927335.427095]
                            })
                        });
var lyr_Burned_Area_Aus_2021_3 = new ol.layer.Image({
                            opacity: 1,
                            title: 'Burned_Area_Aus_2021',
                            
                            
                            source: new ol.source.ImageStatic({
                                url: "./layers/Burned_Area_Aus_2021_3.png",
                                attributions: ' ',
                                projection: 'EPSG:3857',
                                alwaysInRange: true,
                                imageExtent: [12570000.000000, -5425827.902828, 17712000.000000, -1021843.493551]
                            })
                        });
var format_Burned_Area_Polygons_20192020_4 = new ol.format.GeoJSON();
var features_Burned_Area_Polygons_20192020_4 = format_Burned_Area_Polygons_20192020_4.readFeatures(json_Burned_Area_Polygons_20192020_4, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Burned_Area_Polygons_20192020_4 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Burned_Area_Polygons_20192020_4.addFeatures(features_Burned_Area_Polygons_20192020_4);
var lyr_Burned_Area_Polygons_20192020_4 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_Burned_Area_Polygons_20192020_4, 
                style: style_Burned_Area_Polygons_20192020_4,
                popuplayertitle: 'Burned_Area_Polygons_2019-2020',
                interactive: true,
                title: '<img src="styles/legend/Burned_Area_Polygons_20192020_4.png" /> Burned_Area_Polygons_2019-2020'
            });

lyr_GoogleSatellite_0.setVisible(true);lyr_NDVI_1.setVisible(true);lyr_LandSurfTemp_Aus_2019_2.setVisible(true);lyr_Burned_Area_Aus_2021_3.setVisible(true);lyr_Burned_Area_Polygons_20192020_4.setVisible(true);
var layersList = [lyr_GoogleSatellite_0,lyr_NDVI_1,lyr_LandSurfTemp_Aus_2019_2,lyr_Burned_Area_Aus_2021_3,lyr_Burned_Area_Polygons_20192020_4];
lyr_Burned_Area_Polygons_20192020_4.set('fieldAliases', {'count': 'count', 'burned_are': 'burned_are', 'burnDate': 'burnDate', });
lyr_Burned_Area_Polygons_20192020_4.set('fieldImages', {'count': 'Range', 'burned_are': 'Range', 'burnDate': 'TextEdit', });
lyr_Burned_Area_Polygons_20192020_4.set('fieldLabels', {'count': 'no label', 'burned_are': 'no label', 'burnDate': 'no label', });
lyr_Burned_Area_Polygons_20192020_4.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});